package com.helloworld.mapbox.mapbox_helloworld

import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import android.util.Log
import com.mapbox.android.core.location.LocationEngine
import com.navisens.motiondnaapi.MotionDna
import com.navisens.motiondnaapi.MotionDnaApplication
import com.navisens.motiondnaapi.MotionDnaInterface

class MotionDnaDataSource : MotionDnaInterface, LocationEngine {

    override fun activate() {
    }

    override fun removeLocationUpdates() {
        app.stop()
    }

    override fun isConnected(): Boolean {
        return true
    }

    override fun getLastLocation(): Location {
        return last_location
    }

    override fun deactivate() {
    }

    override fun obtainType(): Type {
        return Type.valueOf("NAVISENS")
    }

    override fun requestLocationUpdates() {

    }

    var app: MotionDnaApplication
    var ctx: Context
    var pkg: PackageManager
    var last_location: Location
    var devKey: String


    // Constructor with context and packagemanger for our SDK internal usage.
    constructor(ctx: Context, pkg: PackageManager, devKey: String) : super() {
        this.ctx = ctx
        this.pkg = pkg
        this.last_location = Location("NAVISENS_LOCATION_PROVIDER")
        this.devKey = devKey
        // Instantiating core
        app = MotionDnaApplication(this)
        // Instantiating inertial engine
        app.runMotionDna(devKey)
        // Enabling GPS receivers within SDK.
        app.setExternalPositioningState(MotionDna.ExternalPositioningState.HIGH_ACCURACY)
        // Trigger inertial engine to run with global positional corrections.
        app.setLocationNavisens()
        // Trigger inertial engine to run in pure inertial from given lat lon and heading.
        app.setLocationLatitudeLongitudeAndHeadingInDegrees(37.787742, -122.396859, 315.0)
    }


    override fun getAppContext(): Context {
        return this.ctx
    }

    override fun receiveNetworkData(p0: MotionDna?) {
        Log.e(javaClass.simpleName, "Motion ${p0?.motion?.motionType?.name}")
        Log.e(javaClass.simpleName, "Motion ${p0?.motion?.motionType?.ordinal}")
        Log.e(javaClass.simpleName, "Motion ${p0?.motion?.stepFrequency}")
    }

    override fun receiveNetworkData(p0: MotionDna.NetworkCode?, p1: MutableMap<String, out Any>?) {
        Log.e(javaClass.simpleName, "Motion ${p0?.name}")
        Log.e(javaClass.simpleName, "Motion ${p0?.ordinal}")
    }

    override fun receiveMotionDna(motionDna: MotionDna?) {
        Log.e(javaClass.simpleName, "Receive Motion ${motionDna?.gpsLocation?.absoluteAltitude}")
        Log.e(javaClass.simpleName, "Receive Motion ${motionDna?.location?.heading}")
        Log.e(javaClass.simpleName, "Receive Motion ${motionDna?.motionName}")
        Log.e(javaClass.simpleName, "Receive Motion ${motionDna?.location?.localHeading}")
        Log.e(javaClass.simpleName, "Receive Motion ${motionDna?.location?.proximity}")

        var location = Location("NAVISENS_LOCATION_PROVIDER")
        // MotionDna to android.location object conversion
        motionDna?.let {
            location.latitude = it.location.globalLocation.latitude
            location.longitude = it.location.globalLocation.longitude
            location.bearing = it.location.heading.toFloat() // Bearing doesn't seemed to be used in COMPASS rendering however it is used in GPS render mode.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                location.bearingAccuracyDegrees = 1.0.toFloat()
            }
            location.altitude = it.location.absoluteAltitude
            location.accuracy = it.location.uncertainty.x.toFloat()
            location.time = it.timestamp.toLong()
            location.speed = it.motion.stepFrequency.toFloat()
        }
        var i = 0
        while (i < locationListeners.size) {
            locationListeners[i].onLocationChanged(location)
            ++i
        }
    }

    override fun reportError(errorCode: MotionDna.ErrorCode?, s: String?) {
        when (errorCode) {
            MotionDna.ErrorCode.ERROR_AUTHENTICATION_FAILED -> println("Error: authentication failed $s")
            MotionDna.ErrorCode.ERROR_SDK_EXPIRED -> println("Error: SDK expired $s")
            MotionDna.ErrorCode.ERROR_WRONG_FLOOR_INPUT -> println("Error: wrong floor input $s")
            MotionDna.ErrorCode.ERROR_PERMISSIONS -> println("Error: permissions not granted $s")
            MotionDna.ErrorCode.ERROR_SENSOR_MISSING -> println("Error: sensor missing $s")
            MotionDna.ErrorCode.ERROR_SENSOR_TIMING -> println("Error: sensor timing $s")
        }
    }

    override fun getPkgManager(): PackageManager {
        return this.pkg
    }
}