
This is an example of Navisens' SDK integration with MapBox's SDK.

First get your MapBox token [here](https://www.mapbox.com/account/access-tokens), then retrieve your Navisens Developer Key [here](https://navisens.com/).
Input both keys in the `mapBoxToken` and `navisensDevKey` respectively in the `MainActivity.kt` file.

When you are done with the key retrievals, you can just run the project and it will work out of the box.

Have fun!

![Scheme](mapbox_hello_world.png)
